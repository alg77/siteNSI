# ============================================================
#  MINI-RPG — Séance 3 : Les boucles for et les rencontres aléatoires
# ============================================================
#  NOM Prénom : ______________________
#  Classe     : ______________________
#
#  Consigne : complète les zones marquées ___ directement dans ce
#  fichier, teste dans Spyder, puis AVANT DE RENDRE, renomme ce
#  fichier au format NOM-Prenom-TP3-rpg.py (exemple :
#  DUPONT-Julien-TP3-rpg.py). Dépose-le ensuite sur l'espace de
#  rendu indiqué en classe.
# ============================================================


# ----------------------------------------------------
# | Exercice 3.1 — Les ennemis de la forêt interdite |
# ----------------------------------------------------

# Objectif : Le héros doit traverser une forêt interdite où différents types d'ennemis apparaissent à chaque pas. Simulez 10 rencontres aléatoires avec des ennemis, en utilisant une boucle for.

import random

print("Le héros entre dans la forêt interdite...")

for i in ________(________, ________):
    ennemi = ""
    choix = random.randint(1, 3)
    if choix == 1 : ennemi = "Gobelin"
    if ______ == 2 : ________ = "Troll"
    if ______ == 3 : ________ = "Araignée"
    # Afficher le type d'ennemi rencontré
    print(f"Rencontre {i}: Un {________} apparaît !")

print("Le héros est sorti de la forêt.")


# ----------------------------------------
# | Challenge — Un peu plus de hasard... |
# ----------------------------------------

# Objectif : Reprenez l'exercice précédent et faites en sorte que certains ennemis soient plus rares que d'autres, à l'aide de random.choices et de son paramètre weights vus dans le cours : par exemple 50 % de chances de rencontrer un gobelin, 30 % pour une araignée, 20 % pour un troll.

import random

noms_ennemis = ["Gobelin", "Araignée", "Troll"]
poids_ennemis = [___, ___, ___]   # doit correspondre à 50 % / 30 % / 20 %

print("Le héros entre dans la forêt interdite...")

for i in range(1, 11):
    ennemi = random.________(noms_ennemis, weights=___________)[___]
    print(f"Rencontre {i}: Un {ennemi} apparaît !")

print("Le héros est sorti de la forêt.")

