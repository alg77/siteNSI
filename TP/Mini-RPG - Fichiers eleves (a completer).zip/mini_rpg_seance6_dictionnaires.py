# ============================================================
#  MINI-RPG — Séance 6 : Les dictionnaires
# ============================================================
#  NOM Prénom : ______________________
#  Classe     : ______________________
#
#  Consigne : complète les zones marquées ___ directement dans ce
#  fichier, teste dans Spyder, puis AVANT DE RENDRE, renomme ce
#  fichier au format NOM-Prenom-TP6-rpg.py (exemple :
#  DUPONT-Julien-TP6-rpg.py). Dépose-le ensuite sur l'espace de
#  rendu indiqué en classe.
# ============================================================


# ----------------------------------------
# | Exercice 6.1 — Le bestiaire d'un RPG |
# ----------------------------------------

# Objectif : Créer un dictionnaire nommé bestiaire contenant différentes créatures. Les clés seront les noms des monstres ("Dragon", "Troll", "Gobelin"...), les valeurs une description de chaque créature.

bestiaire = {
    "Dragon": ___________________________________,
    "Troll": ____________________________________,
    "Gobelin": __________________________________
}

print(bestiaire["Dragon"])


# -----------------------------------------------------
# | Exercice 6.2 — Le bestiaire de la forêt interdite |
# -----------------------------------------------------

# Objectif : En vous basant sur l'exemple du menu imbriqué, modifiez le code de la forêt interdite en créant un dictionnaire bestiaire qui contient, pour chaque monstre, ses points de vie (PV), son attaque, sa défense et une description. Adaptez ensuite votre programme pour utiliser ce dictionnaire lors des combats.

bestiaire = {
    "gobelin": {"pv": 40, "attaque": ___, "defense": ___, "description": "___________"},
    "araignee": {"pv": 30, "attaque": ___, "defense": ___, "description": "___________"},
    "troll": {"pv": 70, "attaque": ___, "defense": ___, "description": "___________"}
}

ennemi = random.choice(list(bestiaire.keys()))
stats = bestiaire[___]
print("Un", ennemi, "apparaît !", stats["description"])
print("PV :", stats[___], "- Attaque :", stats["attaque"], "- Défense :", stats[___])


# -------------------------------
# | Challenge — Ajout des héros |
# -------------------------------

# Objectif : Dans un RPG, le joueur peut choisir un type de héros parmi plusieurs archétypes (Mage, Guerrier, Voleur...). Intégrez cette mécanique :

# (voir consignes du cours)

