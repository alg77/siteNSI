# ============================================================
#  MINI-RPG — Séance 5 : Les listes
# ============================================================
#  NOM Prénom : ______________________
#  Classe     : ______________________
#
#  Consigne : complète les zones marquées ___ directement dans ce
#  fichier, teste dans Spyder, puis AVANT DE RENDRE, renomme ce
#  fichier au format NOM-Prenom-TP5-rpg.py (exemple :
#  DUPONT-Julien-TP5-rpg.py). Dépose-le ensuite sur l'espace de
#  rendu indiqué en classe.
# ============================================================


# --------------------------------------
# | Exercice 5.1 — La liste de courses |
# --------------------------------------

# Objectif : Créer un programme qui gère une liste de courses : ajouter des articles, les retirer, et les afficher.

# Initialisation de la liste de courses
______________________ = []

# Boucle pour le menu interactif
while True:
    choix = input("Choisissez une option (a: ajouter, r: retirer, l: lister, q: quitter): ")
    if choix == 'a':
        article = input("Entrez l'article à ajouter : ")
        liste_de_courses.______________(article)
    elif choix == 'r':
        article = input("Entrez l'article à retirer : ")
        if article in liste_de_courses:
            liste_de_courses.______________(article)
        else:
            print("Cet article n'est pas dans la liste.")
    elif choix == 'l':
        print("Voici votre liste de courses : ", ________________________)
    elif choix == 'q':
        print("Fin du programme.")
        break


# --------------------------------------------------------
# | Challenge — Suite du challenge de la forêt interdite |
# --------------------------------------------------------

# Objectif : Faire évoluer le combat de la forêt interdite grâce aux listes.

# --- Étape 1 — une liste de monstres ---
monstres = ["gobelin", "araignee", "troll"]

def choisir_ennemi():
    return random.choice(monstres)

# --- Étape 2 — retirer un monstre vaincu ---
# (voir consignes du cours pour cette étape)

# --- Étape 3 — Attaque et Défense ---
import random

def jet_reussi(valeur_cible):
    de = random.randint(1, 20)
    return de <= valeur_cible

# Test : le héros (Attaque 12) tente une attaque
if jet_reussi(12):
    print("Attaque réussie !")
else:
    print("Attaque manquée.")

# --- Étape 4 — la potion de soin ---
# (voir consignes du cours pour cette étape)

