# ============================================================
#  MINI-RPG — Séance 2 : Le hasard et la première interface graphique
# ============================================================
#  NOM Prénom : ______________________
#  Classe     : ______________________
#
#  Consigne : complète les zones marquées ___ directement dans ce
#  fichier, teste dans Spyder, puis dépose ce fichier sur l'espace
#  de rendu indiqué en classe. Ne renomme pas le fichier.
# ============================================================


# -------------------------------------
# | Exercice 2.1 — L'attaque surprise |
# -------------------------------------

# Objectif : Écrire un programme qui décide aléatoirement si un héros est surpris par un ennemi lorsqu'il entre dans une nouvelle zone. Le programme affiche "Attaque Surprise" si le héros est attaqué et "Aucun ennemi" sinon.

# Importer la fonction nécessaire
from random import ___

# Générer un événement aléatoire
chance = ___()

# Décider si le héros est attaqué par surprise
# Supposons que 50 % du temps, il y a une attaque surprise
if ___ < ___ :
    print("Attaque surprise")
else:
    print("Aucun ennemi")


# ---------------------------------------
# | Exercice 2.2 — Message de bienvenue |
# ---------------------------------------

# Objectif : Créer une fenêtre simple avec Tkinter qui affiche un message d'accueil pour un joueur.

import tkinter as tk

# Création de la fenêtre principale
root = tk.Tk()
___.title("Message RPG")

# Définir la taille de la fenêtre
root.geometry("300x100")  # Largeur x Hauteur

# Création d'un label avec un message d'accueil
message = "Bienvenue, aventurier, dans le monde des défis!"
label = tk.Label(root, text=___)
label.pack(pady=20)  # Ajout de marge verticale

# Lancer l'application
root.___()


# -----------------------------------------------------------------------
# | Exercice 2.3 — Créer une fenêtre pour saisir le nom d'un personnage |
# -----------------------------------------------------------------------

# Objectif : Créer une interface graphique simple où le joueur peut entrer le nom de son personnage et afficher ce nom dans la fenêtre lorsque le bouton est cliqué.

import tkinter as tk

# Affiche le nom du personnage sous le bouton
def afficher_nom():
    character_name = ___.get()
    display_label.config(text=character_name)

# Création de la fenêtre principale
root = tk.Tk()
root.___("Création de Personnage RPG")

# Champ de saisie pour le nom du personnage
name_entry = tk.Entry(root)
name_entry.pack(pady=10)

# Bouton pour afficher le nom du personnage
show_button = tk.Button(root, text="OK", command=___)
show_button.pack(pady=5)

# Label pour afficher le nom du personnage
display_label = tk.Label(root, text="")
display_label.___(pady=10)

root.___()


# ------------------------------------------------------------
# | Challenge — Intégrez une interface graphique à votre RPG |
# ------------------------------------------------------------

# Objectif : Transformer le programme de création de personnage (séance 1) en une application graphique avec Tkinter : nom, classe, force, intelligence, agilité, un bouton de soumission et un récapitulatif affiché.

import ___ as tk

def creer_personnage():
    total_points = 15
    nom_personnage = name_entry.get()
    classe_personnage = class_entry.get()
    force = ___(force_entry.get())
    intelligence = ___(intelligence_entry.get())
    agilite = ___(agility_entry.get())

    recap = "Création de personnage terminée ! \n"
    recap = recap + "Voici les détails de ton héros :\n"
    recap = recap + "Nom : "+nom_personnage +" \n"
    recap = recap + "Classe : "+classe_personnage+"\n"
    recap = recap + "Force : "+str(force)+"\n"
    recap = recap + "Intelligence : "+str(intelligence)+"\n"
    recap = recap + "Agilité : "+str(agilite)+"\n"

    total_points = total_points - (force + intelligence + agilite)
    if total_points == 0:
        recap += "\nTous les points ont été distribués correctement !"
    else:
        recap += ___

    result_label.config(text=recap)

root = tk.Tk()
root.___("Création de personnage du RPG")

tk.Label(root, text="Bienvenue dans la création de personnage du RPG !").grid(row=0, columnspan=2)
tk.Label(root, text="Entrez le nom du personnage:").grid(row=1, column=0)
name_entry = tk.___(root)
name_entry.grid(row=1, column=1)

tk.Label(root, text="Quelle classe veux-tu choisir pour ton personnage ?").grid(row=2, column=0)
class_entry = tk.___(root)
class_entry.grid(row=2, column=1)

tk.Label(root, text="Tu as 15 points de compétence à distribuer.").grid(row=3, columnspan=2)
tk.Label(root, text="Combien de points veux-tu attribuer à la Force ?").grid(row=4, column=0)
force_entry = tk.___(root)
force_entry.grid(row=4, column=1)

tk.Label(root, text="Combien de points veux-tu attribuer à l'Intelligence ?").grid(row=5, column=0)
intelligence_entry = tk.___(root)
intelligence_entry.grid(row=5, column=1)

tk.Label(root, text="Combien de points veux-tu attribuer à l'Agilité ?").grid(row=6, column=0)
agility_entry = tk.___(root)
agility_entry.grid(row=6, column=1)

submit_button = tk.Button(root, text="Soumettre", command=___)
submit_button.grid(row=7, columnspan=2)

result_label = tk.Label(root, text="")
result_label.grid(row=8, columnspan=2)

root.mainloop()

