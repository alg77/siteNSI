# ============================================================
#  MINI-RPG — Séance 2 : Le hasard et les conditions avancées
# ============================================================
#  NOM Prénom : ______________________
#  Classe     : ______________________
#
#  Consigne : complète les zones marquées ___ directement dans ce
#  fichier, teste dans Spyder, puis AVANT DE RENDRE, renomme ce
#  fichier au format NOM-Prenom-TP2-rpg.py (exemple :
#  DUPONT-Julien-TP2-rpg.py). Dépose-le ensuite sur l'espace de
#  rendu indiqué en classe.
# ============================================================


# -------------------------------------
# | Exercice 2.1 — L'attaque surprise |
# -------------------------------------

# Objectif : Écrire un programme qui décide aléatoirement si un héros est surpris par un ennemi lorsqu'il entre dans une nouvelle zone. Le programme affiche "Attaque Surprise" si le héros est attaqué et "Aucun ennemi" sinon.

# Importer le module nécessaire
import ___

# Générer un événement aléatoire
chance = ___.random()

# Décider si le héros est attaqué par surprise
# Supposons que 50 % du temps, il y a une attaque surprise
if ___ < ___ :
    print("Attaque surprise")
else:
    print("Aucun ennemi")


# -------------------------------------
# | Exercice 2.2 — Le butin du coffre |
# -------------------------------------

# Objectif : Tirer un nombre entre 1 et 100 et afficher un butin différent selon sa valeur : commun (50 % de chances), rare (30 %), épique (15 %) ou légendaire (5 %).

import random

tirage = random.___(1, 100)

if tirage <= 50:
    print("Tu trouves une potion de soin. (commun)")
___ tirage <= 80:
    print("Tu trouves une arme rare !")
elif tirage ___ 95:
    print("Tu trouves un objet épique !")
___:
    print("Tu trouves un trésor légendaire !!!")

