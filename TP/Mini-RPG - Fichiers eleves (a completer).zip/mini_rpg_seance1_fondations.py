# ============================================================
#  MINI-RPG — Séance 1 : Variables, affichage et premiers choix
# ============================================================
#  NOM Prénom : ______________________
#  Classe     : ______________________
#
#  Consigne : complète les zones marquées ___ directement dans ce
#  fichier, teste dans Spyder, puis AVANT DE RENDRE, renomme ce
#  fichier au format NOM-Prenom-TP1-rpg.py (exemple :
#  DUPONT-Julien-TP1-rpg.py). Dépose-le ensuite sur l'espace de
#  rendu indiqué en classe.
# ============================================================


# -------------------------------------
# | Exercice 1.1 — Choisis ton destin |
# -------------------------------------

# Objectif : Modifier et étendre le programme initial pour permettre au joueur de choisir une classe pour son héros et afficher un message de bienvenue.

# Demander au joueur d'entrer le nom de son héros
nom_hero = input("Quel est le nom de ton héros ? ")

# Demander au joueur de choisir une classe pour son héros
classe_hero = ___("Quelle est la classe de ton héros ?")

# Afficher un message de bienvenue personnalisé
print("Bienvenue dans le monde de l'aventure,", nom_hero, "le", ___)

___("Que ta quête soit remplie de courage et de gloire !")


# --------------------------------------------
# | Exercice 1.2 — Rencontre avec un gobelin |
# --------------------------------------------

# Objectif : Gérer les points de vie (PV) du héros lors d'une interaction avec un gobelin. Le joueur doit décider d'attaquer ou de se soigner et voir comment cela affecte ses PV.

# Initialisation des variables
pv_hero = 50       # Points de vie initiaux du héros
pv_gobelin = 30    # Points de vie initiaux du gobelin

# Accueil du joueur
___("Tu rencontres un gobelin !")
___("Tu as", pv_hero, "PV et le gobelin en a", ___, ".")

# Choix de l'action
action = ___("Veux-tu attaquer (tape 'attaquer') ou te soigner (tape 'soigner') ? ")

# Logique du jeu basée sur le choix
if action == 'attaquer':
    # Le héros attaque le gobelin
    degats = 10
    # Soustraire les dégâts des PV du gobelin
    pv_gobelin = pv_gobelin ___ degats
    print("Tu infliges", degats, "points de dégâts au gobelin.")
else:
    # Le héros se soigne
    soin = 15
    # Ajouter le soin aux PV du héros
    pv_hero = pv_hero ___ soin
    print("Tu utilises un objet de soin")

# Afficher le statut après l'action
print("Tes points de vie :", ___)
print("Points de vie du gobelin :", ___)


# --------------------------------------
# | Challenge — Création de personnage |
# --------------------------------------

# Objectif : Construire la première étape du jeu RPG en permettant au joueur de créer son propre personnage en choisissant son nom, sa classe, et en distribuant des points de compétence.

# Accueil
______("Bienvenue dans la création de personnage du RPG !")

# Demander le nom du personnage
nom_personnage = ________________________________________

# Choisir la classe du personnage
______("Quelle classe veux-tu choisir pour ton personnage ?")
classe_personnage = _____________________________________

# Attribution des points de compétence
total_points = 15   # Total de points à distribuer
print("Tu as", ________, "points de compétence à distribuer.")

______("Combien de points veux-tu attribuer à la Force ?")
force = int(input())
total_points = ______________________________________________

______("Combien de points veux-tu attribuer à l'Intelligence ?")
intelligence = int(input())
total_points = ______________________________________________

______("Combien de points restants veux-tu attribuer à l'Agilité ?")
agilite = int(input())
total_points = ______________________________________________

# Récapitulatif du personnage créé
______("Création de personnage terminée ! Voici les détails de ton héros :")
print("Nom :", ______________)
print("Classe :", ______________)
print("Force :", ______________)
print("Intelligence :", ______________)
print("Agilité :", ______________)

# Vérifier si tous les points ont été correctement distribués
if total_points == 0:
    print("Tous les points ont été distribués correctement !")
else:
    print("Attention, il semble que la distribution des points soit incorrecte. Il te reste", ______, "points.")

