# ============================================================
#  MINI-RPG — Séance 4 : La boucle while, le combat et l'interface graphique
# ============================================================
#  NOM Prénom : ______________________
#  Classe     : ______________________
#
#  Consigne : complète les zones marquées ___ directement dans ce
#  fichier, teste dans Spyder, puis AVANT DE RENDRE, renomme ce
#  fichier au format NOM-Prenom-TP4-rpg.py (exemple :
#  DUPONT-Julien-TP4-rpg.py). Dépose-le ensuite sur l'espace de
#  rendu indiqué en classe.
# ============================================================


# ----------------------------------------
# | Exercice 4.1 — Un mini-jeu de survie |
# ----------------------------------------

# Objectif : Vous contrôlez un personnage dont la vie commence à 100. Créez un programme qui simule le passage du temps et la perte de vie du personnage en fonction des événements qui se produisent.

vie = 100

while vie ___ 0:
    action = input("Que fais-tu ? (Attaquer / Se défendre / Rien) : ")
    if action == "Attaquer":
        vie = vie ___ 20
    elif action == "Se défendre":
        vie = vie ___ 10
        if vie > 100:
            vie = ___
    else:
        vie = vie ___ 5
    print("Vie restante :", vie)

print("Ton personnage est tombé au combat.")


# -----------------------------------------
# | Exercice 4.2 — Combat avec un monstre |
# -----------------------------------------

# Objectif : Simuler un combat entre votre personnage et un monstre jusqu'à ce que l'un des deux n'ait plus de points de vie.

import random

pv_hero = 100
pv_monstre = 100

while pv_hero > 0 and pv_monstre > 0:
    action = input("Attaquer, Se défendre ou Rien ? : ")
    if action == "Attaquer":
        de = random.randint(1, ___)
        if de > 10:
            pv_monstre = pv_monstre ___ 20
            print("Attaque réussie ! PV monstre :", pv_monstre)
        else:
            print("Attaque manquée.")
    elif action == "Se défendre":
        pv_hero = pv_hero + 10
        if pv_hero > ___:
            pv_hero = 100

    # Tour du monstre
    de_monstre = random.randint(1, 20)
    if de_monstre > 10:
        pv_hero = pv_hero - ___
        print("Le monstre vous touche ! PV héros :", pv_hero)

if pv_hero <= 0:
    print("Vous avez été vaincu...")
else:
    print("Victoire ! Le monstre est vaincu.")


# ----------------------------------------------------
# | Exercice 4.3 — Ta première fenêtre de personnage |
# ----------------------------------------------------

# Objectif : Prendre en main Tkinter : afficher une fenêtre, un champ de saisie et un bouton, et relier un clic à une fonction Python grâce au paramètre command.

import tkinter as tk

# Cette fonction récupère le texte saisi et l'affiche dans le label
def afficher_nom():
    nom = entry.get()
    label_resultat.config(text="Bienvenue, " + ___ + " !")

# Création de la fenêtre principale
root = tk.Tk()
root.___("Création de personnage")

# Champ de saisie pour le nom du héros
entry = tk.Entry(root)
entry.pack(pady=10)

# Bouton relié à la fonction afficher_nom
bouton = tk.Button(root, text="Valider", command=___)
bouton.pack(pady=5)

# Label qui affichera le résultat
label_resultat = tk.Label(root, text="")
label_resultat.___(pady=10)

root.___()


# -----------------------------------------------------
# | Exercice 4.4 — Affichage graphique des rencontres |
# -----------------------------------------------------

# Objectif : Ajouter une image à une interface Tkinter : à chaque clic sur « Nouvelle Rencontre », on affiche le nom d'un ennemi et son image.

# import des librairies nécessaires
import tkinter as tk
from PIL import Image, ImageTk
import random

# Créer la fenêtre principale
fenetre = tk.Tk()
fenetre.title("Rencontres dans la forêt interdite")
fenetre.geometry("600x400")

# Widgets pour le nom et l'image
label_nom = tk.Label(fenetre, text="", font=("Arial", 20))
label_nom.________()
canvas = tk.Canvas(fenetre, width=300, height=300)
canvas.pack()

def choisir_ennemi():
    choix = random.____________(1, 3)
    if choix == 1 : return "gobelin"
    elif __________ == 2 : __________"araignee"
    else : return "troll"

def afficher_rencontre():
    ennemi = choisir_ennemi()
    label_nom.config(text = f"Un {_________} apparaît !")
    # Charger et afficher l'image correspondante
    image_path = ennemi + ".png"
    image = Image.open(image_path)
    image = image.resize((200, 200))
    photo = ImageTk.PhotoImage(image)
    canvas.delete("all")
    canvas.create_image(150, 150, image=photo)
    canvas.image = photo

bouton = tk.Button(fenetre, text="Nouvelle Rencontre", command=afficher_rencontre)
bouton.pack()

fenetre.__________()


# -----------------------------------------------------------
# | Challenge — Gestion d'un combat dans la forêt interdite |
# -----------------------------------------------------------

# Objectif : Assembler tout ce qui vient d'être vu : reprendre le combat au dé à 20 faces (exercice 4.2) et lui donner une interface graphique complète, comme dans l'exercice 4.4.

# (voir consignes du cours)

