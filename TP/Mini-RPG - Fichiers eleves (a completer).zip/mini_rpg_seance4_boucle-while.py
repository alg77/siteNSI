# ============================================================
#  MINI-RPG — Séance 4 : La boucle while et le combat
# ============================================================
#  NOM Prénom : ______________________
#  Classe     : ______________________
#
#  Consigne : complète les zones marquées ___ directement dans ce
#  fichier, teste dans Spyder, puis dépose ce fichier sur l'espace
#  de rendu indiqué en classe. Ne renomme pas le fichier.
# ============================================================


# ----------------------------------------
# | Exercice 4.1 — Un mini-jeu de survie |
# ----------------------------------------

# Objectif : Vous contrôlez un personnage dont la vie commence à 100. Créez un programme qui simule le passage du temps et la perte de vie du personnage en fonction des événements qui se produisent.

vie = 100

while vie ___ 0:
    action = input("Que fais-tu ? (Attaquer / Se défendre / Rien) : ")
    if action == "Attaquer":
        vie = vie ___ 20
    elif action == "Se défendre":
        vie = vie ___ 10
        if vie > 100:
            vie = ___
    else:
        vie = vie ___ 5
    print("Vie restante :", vie)

print("Ton personnage est tombé au combat.")


# -----------------------------------------
# | Exercice 4.2 — Combat avec un monstre |
# -----------------------------------------

# Objectif : Simuler un combat entre votre personnage et un monstre jusqu'à ce que l'un des deux n'ait plus de points de vie.

import random

pv_hero = 100
pv_monstre = 100

while pv_hero > 0 and pv_monstre > 0:
    action = input("Attaquer, Se défendre ou Rien ? : ")
    if action == "Attaquer":
        de = random.randint(1, ___)
        if de > 10:
            pv_monstre = pv_monstre ___ 20
            print("Attaque réussie ! PV monstre :", pv_monstre)
        else:
            print("Attaque manquée.")
    elif action == "Se défendre":
        pv_hero = pv_hero + 10
        if pv_hero > ___:
            pv_hero = 100

    # Tour du monstre
    de_monstre = random.randint(1, 20)
    if de_monstre > 10:
        pv_hero = pv_hero - ___
        print("Le monstre vous touche ! PV héros :", pv_hero)

if pv_hero <= 0:
    print("Vous avez été vaincu...")
else:
    print("Victoire ! Le monstre est vaincu.")


# -----------------------------------------------------------
# | Challenge — Gestion d'un combat dans la forêt interdite |
# -----------------------------------------------------------

# Objectif : En réutilisant le TP précédent sur la forêt interdite, ajouter une interface graphique complète au combat : un monstre choisi au hasard parmi 2 ou 3, son image affichée, des boutons pour attaquer / se défendre / ne rien faire, un bouton « choisir un nouveau monstre », et les points de vie affichés en temps réel.

# (voir consignes du cours)

