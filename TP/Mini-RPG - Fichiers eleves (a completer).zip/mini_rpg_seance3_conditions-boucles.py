# ============================================================
#  MINI-RPG — Séance 3 : Conditions, indentation et boucles for
# ============================================================
#  NOM Prénom : ______________________
#  Classe     : ______________________
#
#  Consigne : complète les zones marquées ___ directement dans ce
#  fichier, teste dans Spyder, puis dépose ce fichier sur l'espace
#  de rendu indiqué en classe. Ne renomme pas le fichier.
# ============================================================


# ----------------------------------------------------------------------
# | Exercice 3.1 — Les ennemis de la forêt interdite (version console) |
# ----------------------------------------------------------------------

# Objectif : Le héros doit traverser une forêt interdite où différents types d'ennemis apparaissent à chaque pas. Simulez 10 rencontres aléatoires avec des ennemis, certains plus rares que d'autres.

import random

print("Le héros entre dans la forêt interdite...")

for i in ________(________, ________):
    ennemi = ""
    choix = random.randint(1, 3)
    if choix == 1 : ennemi = "Gobelin"
    if ______ == 2 : ________ = "Troll"
    if ______ == 3 : ________ = "Araignée"
    # Afficher le type d'ennemi rencontré
    print(f"Rencontre {i}: Un {________} apparaît !")

print("Le héros est sorti de la forêt.")


# -----------------------------------------------------
# | Exercice 3.2 — Affichage graphique des rencontres |
# -----------------------------------------------------

# Objectif : Ajouter une interface graphique : à chaque rencontre, on affiche le nom de l'ennemi et une image le représentant, avec un bouton « Nouvelle Rencontre ».

# import des librairies nécessaires
import tkinter as tk
from PIL import Image, ImageTk
___________ random

# Créer la fenêtre principale
fenetre = tk.Tk()
fenetre.title("Rencontres dans la forêt interdite")
fenetre.geometry("600x400")

# Widgets pour le nom et l'image
label_nom = tk.Label(fenetre, text="", font=("Arial", 20))
label_nom.________()
canvas = tk.Canvas(fenetre, width=300, height=300)
canvas.pack()

def choisir_ennemi():
    choix = random.____________(1, 3)
    if choix == 1 : return "gobelin"
    elif __________ == 2 : __________"araignee"
    else : return "troll"

def afficher_rencontre():
    ennemi = choisir_ennemi()
    label_nom.config(text = f"Un {_________} apparaît !")
    # Charger et afficher l'image correspondante
    image_path = ennemi + ".png"
    image = Image.open(image_path)
    image = image.resize((200, 200))
    photo = ImageTk.PhotoImage(image)
    canvas.delete("all")
    canvas.create_image(150, 150, image=photo)
    canvas.image = photo

bouton = tk.Button(fenetre, text="Nouvelle Rencontre", command=afficher_rencontre)
bouton.pack()

fenetre.__________()


# -------------------------------------
# | Challenge — Enrichir le bestiaire |
# -------------------------------------

# Objectif : Utiliser une IA (Copilot ou autre) pour générer une image d'un monstre dans un style rétro (pixel, 8-bits), puis intégrer ce nouveau monstre dans votre « forêt interdite ».

# (voir consignes du cours)

