@echo off
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0lancer_atelier.py"
) else (
    python "%~dp0lancer_atelier.py"
)
pause
