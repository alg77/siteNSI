# La forêt interdite — Mini RPG Python

Extrais ce dossier avant de travailler. Avec Python 3 installé, lance **Ouvrir_atelier_Windows.cmd** sous Windows, ou exécute `python lancer_atelier.py`. Garde la fenêtre du lanceur ouverte. Le navigateur affiche l’atelier sur une adresse locale.

Une connexion Internet est nécessaire pour télécharger le moteur Python. Un double-clic sur index.html permet de lire le cours, mais pas d’exécuter Python. Si le moteur est bloqué, utilise le fichier mini_rpg_eleve.py dans Python sur ordinateur.

Dans l’atelier, les réponses à input sont préparées une par ligne. L’onglet Mon travail est exporté ; l’onglet Exemple · bac à sable sert à expérimenter. Télécharge ton fichier à chaque séance et utilise Reprendre un fichier .py pour continuer sur un autre poste.

Le fichier **cours_exemples_mini_rpg.pdf** regroupe les sept cours, les exemples, les résultats attendus, les exercices intermédiaires et les missions. Le cahier Word et le fichier Markdown contiennent le même contenu, avec tous les indices.

À rendre : **NOM_Prenom_mini_rpg.py**, avec les six parties, les tests demandés (au moins deux tests commentés par partie) et les aides utilisées. Le menu fourni permet de lancer une seule partie. Garde les marqueurs pour pouvoir réimporter ton fichier. Le dépôt sur l’ENT ou Classroom se fait selon les consignes du professeur.

Chaque partie a ses critères de réussite (repères sur 5) pour vérifier ton travail. Ce TP est un entraînement : l’évaluation notée se fait en TP individuel, sur un sujet tiré au sort. Tu dois pouvoir expliquer et modifier tes lignes de code.

La partie 7 (interface graphique avec Tkinter) se fait sur ordinateur, dans Thonny ou IDLE : pars de interface_rpg_eleve.py et copie à côté de ton fichier .py l’image assets/fond_foret.png et les trois monstres du dossier assets/monstres. À rendre : NOM_Prenom_rpg_interface.py.

## Repères pour chaque partie

Du TP2 au TP4, reprends la création du personnage du TP1 : dégâts force + 3, soin 10 + intelligence, seuil 20 - agilite. Chaque partie se lance seule. Le TP2 demande six fonctions à définir, 19 appels de test avec print et une scène à vérifier. Le TP3 est un parcours court ; le compteur est facultatif.

Au TP5, la règle de combat change (fonction est_attaque_passee) : attaque du héros = 7 + force, défense = 4 + agilite ; monstres à 40 PV, attaque 9, défense 7 ; deux dés à 20 faces par attaque, 20 dégâts si l’attaque touche et n’est pas bloquée. Dans les saisies, termine le menu de courses par q, puis écris le personnage et une action par ligne.

Partie 6 : mini-cours sur les dictionnaires, échauffements de déroulement, explication de .copy() et personnage personnel. Les étapes 1 à 5 de la mission forment le rendu de base ; le bestiaire imbriqué et le combat sont des prolongements.
