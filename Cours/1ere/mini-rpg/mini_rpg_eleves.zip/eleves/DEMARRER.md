# La forêt interdite — Mini RPG Python

Extrais ce dossier avant de travailler. Avec Python 3 installé, lance **Ouvrir_atelier_Windows.cmd** sous Windows, ou exécute `python lancer_atelier.py`. Garde la fenêtre du lanceur ouverte. Le navigateur affiche l’atelier sur une adresse locale.

Une connexion Internet est nécessaire pour télécharger le moteur Python. Un double-clic sur index.html permet de lire le cours, mais pas d’exécuter Python. Si le moteur est bloqué, utilise le fichier mini_rpg_eleve.py dans Python sur ordinateur.

Dans l’atelier, les réponses à input sont préparées une par ligne. L’onglet Mon travail est exporté ; l’onglet Exemple est un bac à sable. Télécharge ton fichier à chaque séance et utilise Reprendre un fichier .py pour continuer sur un autre poste.

Le fichier **cours_exemples_mini_rpg.pdf** regroupe les six cours, les exemples, les résultats attendus et les exercices intermédiaires. Il peut être téléchargé depuis l’accueil du site ou imprimé.

À rendre : **NOM_Prenom_mini_rpg.py**, avec les six parties, deux tests commentés par partie et les aides utilisées. Le menu fourni permet de lancer une seule partie. Garde les marqueurs pour pouvoir réimporter ton fichier. Le dépôt sur l’ENT ou Classroom reste à faire selon les consignes du professeur.

Les critères figurent à chaque étape : 6 × 5 points, puis oral /10 ; note sur 20 = (écrit + oral) /2. Tu dois pouvoir expliquer et modifier tes lignes de code.

Les fichiers Word et Markdown contiennent également le cours. Tkinter est un atelier complémentaire sur ordinateur ; les images ne sont pas nécessaires au parcours principal.


## Aides des TP2 et TP3

Le TP2 de deux heures demande six fonctions à définir, 19 appels de test avec print et une scène à vérifier. Les indices 3 sont réservés aux deux premières étapes et aux deux premiers échauffements de chaque TP. Le cours, les consignes et les indices à jour se trouvent dans index.html et cahier_eleve.md. Du TP2 au TP4, reprendre la création du personnage du TP1 : dégâts force + 3, soin 10 + intelligence, seuil 20 - agilite. Chaque partie se lance seule. Le TP3 propose un parcours court après le DST ; le compteur est facultatif. Le PDF et le cahier Word restent les supports de synthèse antérieurs.
