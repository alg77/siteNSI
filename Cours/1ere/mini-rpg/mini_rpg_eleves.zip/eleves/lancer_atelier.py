"""Ouvre l'atelier sur cet ordinateur. Python 3, aucune installation supplémentaire."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
import webbrowser

if __name__ == "__main__":
    dossier = Path(__file__).resolve().parent
    gestionnaire = partial(SimpleHTTPRequestHandler, directory=str(dossier))
    with ThreadingHTTPServer(("127.0.0.1", 0), gestionnaire) as serveur:
        adresse = f"http://127.0.0.1:{serveur.server_port}/index.html"
        print("Atelier Mini RPG :", adresse)
        print("Garder cette fenêtre ouverte. Ctrl+C pour arrêter.")
        print("Connexion Internet nécessaire pour charger le moteur Python.")
        webbrowser.open(adresse)
        try:
            serveur.serve_forever()
        except KeyboardInterrupt:
            print("\nAtelier arrêté.")
